"""Создание воспроизводимого учебного набора событий ИБ (180 записей).

Запуск: python generate_events.py
Скрипт перезапишет events.json в каталоге проекта.
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timedelta
from pathlib import Path

SEED = 20261123
EVENT_TYPES = [
    ("Multiple Failed Login Attempts", 45, "medium", "blocked", "authentication"),
    ("Port Scanning Detected", 30, "low", "blocked", "network"),
    ("Suspicious PowerShell Execution", 26, "high", "alerted", "endpoint"),
    ("Malware Signature Detected", 22, "critical", "quarantined", "endpoint"),
    ("Brute Force Attack", 20, "high", "blocked", "authentication"),
    ("Unauthorized Access Attempt", 18, "high", "blocked", "access_control"),
    ("DNS Tunneling Suspected", 12, "high", "alerted", "network"),
    ("Data Exfiltration Alert", 7, "critical", "alerted", "data_protection"),
]


def build_events() -> list[dict]:
    rng = random.Random(SEED)
    events = []

    for signature, count, severity, action, category in EVENT_TYPES:
        for _ in range(count):
            day = rng.randint(0, 6)
            timestamp = datetime(2026, 11, 10, rng.randint(0, 23),
                                 rng.randint(0, 59), rng.randint(0, 59))
            timestamp += timedelta(days=day)
            events.append({
                "timestamp": timestamp.isoformat() + "Z",
                "signature": signature,
                "severity": severity,
                "action": action,
                "category": category,
                "src_ip": f"198.51.100.{rng.randint(1, 254)}",
                "dst_ip": f"192.168.10.{rng.randint(10, 230)}",
                "protocol": rng.choice(["TCP", "TCP", "TCP", "UDP"]),
                "dst_port": {
                    "authentication": 3389,
                    "network": 53 if "DNS" in signature else 443,
                    "endpoint": 445,
                    "access_control": 22,
                    "data_protection": 443,
                }[category],
            })

    rng.shuffle(events)
    for index, event in enumerate(events, start=1):
        event["event_id"] = f"EVT-{index:04d}"
    return events


if __name__ == "__main__":
    output = Path(__file__).resolve().parent / "events.json"
    output.write_text(json.dumps(build_events(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Сгенерировано 180 событий: {output}")
